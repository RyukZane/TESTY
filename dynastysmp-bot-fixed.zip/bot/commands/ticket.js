const { SlashCommandBuilder: S, ChannelType, EmbedBuilder, PermissionFlagsBits: P } = require('discord.js');
const db = require('../lib/db'); const tk = require('../lib/tickets');
const { EPH, isAdmin, isStaff, say, dur, validEmoji } = require('../lib/util');
const STYLES = [{ name: 'Green', value: 'Success' }, { name: 'Red', value: 'Danger' }, { name: 'Blue', value: 'Primary' }, { name: 'Grey', value: 'Secondary' }];
const user = (s, d = 'User') => s.addUserOption(o => o.setName('user').setDescription(d).setRequired(true));

const data = new S().setName('ticket').setDescription('Ticket system')
  .addSubcommand(s => s.setName('setup').setDescription('Set up tickets: panel channel, logs, support role + a category per ticket type')
    .addChannelOption(o => o.setName('panel_channel').setDescription('Channel for the ticket panel').addChannelTypes(ChannelType.GuildText).setRequired(true))
    .addChannelOption(o => o.setName('logs_channel').setDescription('Ticket logs channel').addChannelTypes(ChannelType.GuildText).setRequired(true))
    .addRoleOption(o => o.setName('support_role').setDescription('Role that can see, claim and close tickets').setRequired(true)))
  .addSubcommand(s => s.setName('panel').setDescription('Send (or refresh) the ticket panel')
    .addChannelOption(o => o.setName('channel').setDescription('Channel (default: saved panel channel)').addChannelTypes(ChannelType.GuildText)))
  .addSubcommandGroup(g => g.setName('supportrole').setDescription('Roles that can claim/close tickets')
    .addSubcommand(s => s.setName('add').setDescription('Add a support role').addRoleOption(o => o.setName('role').setDescription('Role').setRequired(true)))
    .addSubcommand(s => s.setName('remove').setDescription('Remove a support role').addRoleOption(o => o.setName('role').setDescription('Role').setRequired(true))))
  .addSubcommandGroup(g => g.setName('category').setDescription('Manage ticket categories')
    .addSubcommand(s => s.setName('add').setDescription('Add a category')
      .addStringOption(o => o.setName('name').setDescription('Category name').setRequired(true))
      .addStringOption(o => o.setName('emoji').setDescription('Emoji'))
      .addStringOption(o => o.setName('style').setDescription('Button color').addChoices(...STYLES))
      .addStringOption(o => o.setName('description').setDescription('Description shown on the panel')))
    .addSubcommand(s => s.setName('edit').setDescription('Edit a category (emoji, color, description, name)')
      .addStringOption(o => o.setName('name').setDescription('Category name or id').setRequired(true))
      .addStringOption(o => o.setName('emoji').setDescription('New emoji (unicode or custom)'))
      .addStringOption(o => o.setName('style').setDescription('Button color').addChoices(...STYLES))
      .addStringOption(o => o.setName('new_name').setDescription('New name'))
      .addStringOption(o => o.setName('description').setDescription('New description')))
    .addSubcommand(s => s.setName('remove').setDescription('Remove a category').addStringOption(o => o.setName('name').setDescription('Category name or id').setRequired(true)))
    .addSubcommand(s => s.setName('list').setDescription('List categories')))
  .addSubcommandGroup(g => g.setName('blacklist').setDescription('Block users from opening tickets')
    .addSubcommand(s => user(s.setName('add').setDescription('Blacklist a user')))
    .addSubcommand(s => user(s.setName('remove').setDescription('Remove from blacklist'))))
  .addSubcommand(s => user(s.setName('add').setDescription('Add a user to this ticket')))
  .addSubcommand(s => user(s.setName('remove').setDescription('Remove a user from this ticket')))
  .addSubcommand(s => s.setName('rename').setDescription('Rename this ticket').addStringOption(o => o.setName('name').setDescription('New name').setRequired(true)))
  .addSubcommand(s => s.setName('leaderboard').setDescription('Top staff by tickets handled')
    .addStringOption(o => o.setName('period').setDescription('Time range').addChoices({ name: 'Today', value: 'today' }, { name: 'This week', value: 'week' }, { name: 'This month', value: 'month' }, { name: 'All time', value: 'all' }))
    .addStringOption(o => o.setName('sort').setDescription('Rank by').addChoices({ name: 'Closed', value: 'closed' }, { name: 'Claimed', value: 'claimed' }, { name: 'Rating', value: 'rating' }))
    .addStringOption(o => o.setName('category').setDescription('Only this category (name or id)')))
  .addSubcommand(s => s.setName('stats').setDescription('Stats for a staff member').addUserOption(o => o.setName('user').setDescription('Staff member (default: you)')))
  .addSubcommand(s => s.setName('serverstats').setDescription('Server-wide ticket stats'))
  .addSubcommand(s => s.setName('settings').setDescription('Show ticket settings'));

module.exports = { data, async run(ctx) {
  const sub = ctx.opts.getSubcommand(), grp = ctx.opts.getSubcommandGroup(false), g = ctx.guild, o = ctx.opts, s = db.get(g.id);
  const deny = t => ctx.reply({ content: t, flags: EPH });
  if ((grp || ['setup', 'panel', 'settings'].includes(sub)) && !isAdmin(ctx.member)) return deny('❌ Only admins / Manage Server can use this.');
  const refresh = () => { const pc = g.channels.cache.get(db.get(g.id).ticket.panelCh); return pc ? tk.sendPanel(pc, g.id).catch(() => { }) : null; };
  const inTicket = !grp && ['add', 'remove', 'rename'].includes(sub);
  if (inTicket) { if (!tk.getT(ctx.channel.id)) return deny('❌ Use this inside a ticket channel.'); if (!isStaff(ctx.member, s)) return deny('❌ Staff only.'); }

  if (!grp && sub === 'setup') {
    await ctx.defer(true);
    const pc = o.getChannel('panel_channel'), lc = o.getChannel('logs_channel'), role = o.getRole('support_role');
    db.mut(g.id, 'ticket', t => { t.logCh = lc.id; if (!t.roles.includes(role.id)) t.roles.push(role.id); });
    for (const c of db.get(g.id).ticket.cats) await tk.ensureParent(g, c.id);
    await tk.sendPanel(pc, g.id);
    return ctx.reply({ ...say(`✅ **Ticket system ready!**\n• Panel: ${pc}\n• Logs: ${lc}\n• Support role: ${role}\n• A Discord category was created for each ticket type — tickets open inside their own category.\n\nCustomize with \`/ticket category add\`, \`/ticket supportrole add\`.`, 0x57F287), flags: EPH });
  }
  if (!grp && sub === 'panel') {
    const ch = o.getChannel('channel') || g.channels.cache.get(s.ticket.panelCh); if (!ch) return deny('❌ Run `/ticket setup` first or pass a channel.');
    await tk.sendPanel(ch, g.id); return ctx.reply({ content: `✅ Panel sent in ${ch}.`, flags: EPH });
  }
  if (grp === 'supportrole') {
    const r = o.getRole('role');
    db.mut(g.id, 'ticket', t => { t.roles = sub === 'add' ? [...new Set([...t.roles, r.id])] : t.roles.filter(x => x !== r.id); });
    return ctx.reply(say(`✅ ${r} ${sub === 'add' ? 'can now' : 'can no longer'} claim and close tickets.`, 0x57F287));
  }
  if (grp === 'category') {
    if (sub === 'list') return ctx.reply(say(s.ticket.cats.map(c => `${c.emoji} **${c.name}** (\`${c.id}\`) — ${c.desc}`).join('\n')));
    if (sub === 'add') {
      const name = o.getString('name'), id = name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 20) || 'cat';
      if (o.getString('emoji') && !validEmoji(o.getString('emoji'))) return deny('❌ Send a real emoji (unicode, or a custom one like <:name:123>).');
      if (s.ticket.cats.length >= 8) return deny('❌ Max 8 categories.'); if (s.ticket.cats.some(c => c.id === id)) return deny('❌ That category already exists.');
      db.mut(g.id, 'ticket', t => t.cats.push({ id, name, emoji: o.getString('emoji') || '🎫', style: o.getString('style') || 'Secondary', desc: o.getString('description') || 'Open a ticket.', q: [['Describe your request', 'p']], parent: null }));
      await tk.ensureParent(g, id); await refresh();
      return ctx.reply(say(`✅ Category **${name}** added and the panel refreshed.`, 0x57F287));
    }
    if (sub === 'edit') {
      const n = o.getString('name').toLowerCase(), c = s.ticket.cats.find(c => c.id === n || c.name.toLowerCase() === n); if (!c) return deny('❌ Category not found.');
      if (o.getString('emoji') && !validEmoji(o.getString('emoji'))) return deny('❌ Send a real emoji (unicode, or a custom one like <:name:123>).');
      db.mut(g.id, 'ticket', t => { const x = t.cats.find(y => y.id === c.id); if (o.getString('emoji')) x.emoji = o.getString('emoji'); if (o.getString('style')) x.style = o.getString('style'); if (o.getString('description')) x.desc = o.getString('description'); if (o.getString('new_name')) x.name = o.getString('new_name'); });
      if (o.getString('new_name') && c.parent) g.channels.cache.get(c.parent)?.setName(`${process.env.BRAND || 'DynastySMP'} • ${o.getString('new_name')}`.slice(0, 100)).catch(() => { });
      await refresh(); return ctx.reply(say(`✅ **${c.name}** updated and the panel refreshed.`, 0x57F287));
    }
    if (sub === 'remove') {
      const n = o.getString('name').toLowerCase(), c = s.ticket.cats.find(c => c.id === n || c.name.toLowerCase() === n); if (!c) return deny('❌ Category not found.');
      db.mut(g.id, 'ticket', t => { t.cats = t.cats.filter(x => x.id !== c.id); });
      await refresh();
      return ctx.reply(say(`✅ Removed **${c.name}** (its Discord category was kept).`, 0x57F287));
    }
  }
  if (grp === 'blacklist') {
    const u = o.getUser('user');
    db.mut(g.id, 'ticket', t => { t.blacklist = sub === 'add' ? [...new Set([...t.blacklist, u.id])] : t.blacklist.filter(x => x !== u.id); });
    return ctx.reply(say(`✅ ${u} ${sub === 'add' ? 'is now blocked from' : 'can open'} tickets.`, 0x57F287));
  }
  if (sub === 'add') { await ctx.channel.permissionOverwrites.edit(o.getUser('user'), { ViewChannel: true, SendMessages: true, ReadMessageHistory: true, AttachFiles: true }); return ctx.reply(say(`✅ Added ${o.getUser('user')} to this ticket.`, 0x57F287)); }
  if (sub === 'remove') { await ctx.channel.permissionOverwrites.delete(o.getUser('user')); return ctx.reply(say(`✅ Removed ${o.getUser('user')} from this ticket.`, 0x57F287)); }
  if (sub === 'rename') { await ctx.channel.setName(o.getString('name').toLowerCase().replace(/[^a-z0-9-_]/g, '-').slice(0, 95)); return ctx.reply(say('✅ Renamed.', 0x57F287)); }

  if (sub === 'leaderboard') {
    const ms = { today: 864e5, week: 6048e5, month: 2592e6 }[o.getString('period')], sort = o.getString('sort') || 'closed', cq = o.getString('category')?.toLowerCase();
    const cat = cq && s.ticket.cats.find(c => c.id === cq || c.name.toLowerCase() === cq); if (cq && !cat) return deny('❌ Unknown category.');
    const rows = db.raw.prepare(`SELECT claimed_by u,COUNT(*) claimed,SUM(status='closed') closed,AVG(rating) r FROM tickets WHERE guild=? AND claimed_by IS NOT NULL AND first_response IS NOT NULL AND opened_at>=? ${cat ? 'AND category=?' : ''} GROUP BY claimed_by`)
      .all(...[g.id, ms ? Date.now() - ms : 0, ...(cat ? [cat.id] : [])]);
    rows.sort((a, b) => sort === 'rating' ? (b.r || 0) - (a.r || 0) : b[sort] - a[sort]);
    if (!rows.length) return ctx.reply(say('No ticket data yet for that filter.'));
    const medals = ['🥇', '🥈', '🥉'], me = rows.findIndex(r => r.u === ctx.user.id);
    const e = new EmbedBuilder().setColor(0xFEE75C).setTitle(`🏆 Ticket Leaderboard${cat ? ` • ${cat.name}` : ''}`)
      .setDescription(rows.slice(0, 10).map((r, n) => `${medals[n] || `**${n + 1}.**`} <@${r.u}> • ${r.claimed} claimed • ${r.closed} closed • ${r.r ? `⭐ ${r.r.toFixed(1)}` : 'no ratings'}`).join('\n'))
      .setFooter({ text: `${o.getString('period') || 'all time'} • ranked by ${sort}${me >= 0 ? ` • your rank: #${me + 1}` : ''}` });
    return ctx.reply({ embeds: [e] });
  }
  if (sub === 'stats') {
    const u = o.getUser('user') || ctx.user;
    const r = db.raw.prepare("SELECT COUNT(*) claimed,SUM(status='closed') closed,AVG(first_response-opened_at) resp,AVG(closed_at-opened_at) res,AVG(rating) rate FROM tickets WHERE guild=? AND claimed_by=?").get(g.id, u.id);
    return ctx.reply({ embeds: [new EmbedBuilder().setColor(0x5865F2).setTitle(`📊 Ticket stats • ${u.username}`).addFields(
      { name: 'Claimed', value: `${r.claimed}`, inline: true }, { name: 'Closed', value: `${r.closed || 0}`, inline: true }, { name: 'Avg rating', value: r.rate ? `⭐ ${r.rate.toFixed(2)}` : 'n/a', inline: true },
      { name: 'Avg first response', value: dur(r.resp), inline: true }, { name: 'Avg resolution', value: dur(r.res), inline: true })] });
  }
  if (sub === 'serverstats') {
    const r = db.raw.prepare("SELECT COUNT(*) total,SUM(status='open') open,SUM(status='closed') closed,AVG(closed_at-opened_at) res,AVG(rating) rate FROM tickets WHERE guild=?").get(g.id);
    const top = db.raw.prepare('SELECT category,COUNT(*) n FROM tickets WHERE guild=? GROUP BY category ORDER BY n DESC LIMIT 1').get(g.id);
    return ctx.reply({ embeds: [new EmbedBuilder().setColor(0x5865F2).setTitle('📊 Server ticket stats').addFields(
      { name: 'Total', value: `${r.total}`, inline: true }, { name: 'Open', value: `${r.open || 0}`, inline: true }, { name: 'Closed', value: `${r.closed || 0}`, inline: true },
      { name: 'Avg resolution', value: dur(r.res), inline: true }, { name: 'Avg rating', value: r.rate ? `⭐ ${r.rate.toFixed(2)}` : 'n/a', inline: true },
      { name: 'Busiest category', value: top ? (s.ticket.cats.find(c => c.id === top.category)?.name || top.category) + ` (${top.n})` : 'n/a', inline: true })] });
  }
  if (sub === 'settings') {
    const t = s.ticket;
    return ctx.reply(say(`**Panel:** ${t.panelCh ? `<#${t.panelCh}>` : 'not set'}\n**Logs:** ${t.logCh ? `<#${t.logCh}>` : 'not set'}\n**Support roles:** ${t.roles.map(r => `<@&${r}>`).join(' ') || 'none'}\n**Max open per user:** ${t.max}\n**Blacklisted:** ${t.blacklist.length}\n**Categories:** ${t.cats.map(c => `${c.emoji} ${c.name}`).join(', ')}`));
  }
} };
