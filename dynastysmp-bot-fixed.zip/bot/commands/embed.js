const { SlashCommandBuilder: S, EmbedBuilder, PermissionFlagsBits: P, ChannelType } = require('discord.js');
const { EPH, parseColor, COLOR_HELP, say } = require('../lib/util');
const txt = s => s?.replace(/\\n/g, '\n');
const data = new S().setName('embed').setDescription('Create and edit embeds').setDefaultMemberPermissions(P.ManageMessages)
  .addSubcommand(s => s.setName('create').setDescription('Create and send an embed')
    .addStringOption(o => o.setName('title').setDescription('Title'))
    .addStringOption(o => o.setName('description').setDescription('Text (use \\n for new line)'))
    .addStringOption(o => o.setName('color').setDescription('none, red, blue, green, yellow, orange, purple, pink, black, white, grey or #hex'))
    .addStringOption(o => o.setName('footer').setDescription('Footer text'))
    .addStringOption(o => o.setName('author').setDescription('Author line'))
    .addBooleanOption(o => o.setName('timestamp').setDescription('Show timestamp'))
    .addAttachmentOption(o => o.setName('image').setDescription('Upload a big image from your device'))
    .addAttachmentOption(o => o.setName('thumbnail').setDescription('Upload a small image from your device'))
    .addChannelOption(o => o.setName('channel').setDescription('Where to send (default: here)').addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement))
    .addRoleOption(o => o.setName('ping').setDescription('Role to ping')))
  .addSubcommand(s => s.setName('edit').setDescription('Edit an embed the bot sent')
    .addStringOption(o => o.setName('message_id').setDescription('Message ID').setRequired(true))
    .addStringOption(o => o.setName('title').setDescription('New title'))
    .addStringOption(o => o.setName('description').setDescription('New text'))
    .addStringOption(o => o.setName('color').setDescription('New color (or none)'))
    .addChannelOption(o => o.setName('channel').setDescription('Channel of the message (default: here)')));

module.exports = { data, perm: P.ManageMessages, async run(ctx) {
  const o = ctx.opts, bad = t => ctx.reply({ content: t, flags: EPH });
  const c = parseColor(o.getString('color')); if (!c.ok) return bad(`❌ Invalid color. Use: ${COLOR_HELP}`);
  if (o.getSubcommand() === 'edit') {
    const ch = o.getChannel('channel') || ctx.channel, msg = await ch.messages.fetch(o.getString('message_id')).catch(() => null);
    if (!msg || msg.author.id !== ctx.client.user.id || !msg.embeds[0]) return bad('❌ I can only edit embeds I sent. Check the message ID / channel.');
    const e = new EmbedBuilder(msg.embeds[0].data);
    if (o.getString('title')) e.setTitle(o.getString('title')); if (o.getString('description')) e.setDescription(txt(o.getString('description')));
    if (o.getString('color')) e.setColor(c.color);
    await msg.edit({ embeds: [e] }); return ctx.reply({ ...say('✅ Embed updated.', 0x57F287), flags: EPH });
  }
  const e = new EmbedBuilder(), title = o.getString('title'), desc = txt(o.getString('description'));
  if (title) e.setTitle(title.slice(0, 256)); if (desc) e.setDescription(desc.slice(0, 4000));
  if (c.color !== null) e.setColor(c.color);                     // 'none' / empty -> no color
  if (o.getString('footer')) e.setFooter({ text: o.getString('footer').slice(0, 2048) });
  if (o.getString('author')) e.setAuthor({ name: o.getString('author').slice(0, 256) });
  if (o.getBoolean('timestamp')) e.setTimestamp();
  const files = [];
  for (const [key, fn] of [['image', 'setImage'], ['thumbnail', 'setThumbnail']]) {   // images uploaded straight from the device, no URL needed
    const a = o.getAttachment(key); if (!a) continue;
    if (!(a.contentType?.startsWith('image/') || /\.(png|jpe?g|gif|webp)$/i.test(a.name))) return bad(`❌ \`${key}\` must be an image (png, jpg, gif, webp).`);
    if (a.size > 8 * 1024 * 1024) return bad('❌ Image too large (max 8 MB).');
    const name = `${key}_${Date.now()}.${(a.name.split('.').pop() || 'png').toLowerCase()}`;
    files.push({ attachment: a.url, name }); e[fn](`attachment://${name}`);
  }
  if (!title && !desc && !files.length) return bad('❌ Give at least a title, description or image.');
  const ch = o.getChannel('channel') || ctx.channel, ping = o.getRole('ping');
  await ch.send({ content: ping ? `${ping}` : undefined, embeds: [e], files, allowedMentions: { parse: ['roles'] } });
  if (ctx.isSlash) return ctx.reply({ ...say(`✅ Embed sent in ${ch}.`, 0x57F287), flags: EPH });
  ctx.src.delete().catch(() => { });
} };
